<?php 

$NMSConfig = include getcwd() . '/config.php';
return $NMSConfig;