<?php

class PluginData extends Eloquent {

	protected $table = 'plugin_data';

	protected $guarded = array();

	public static $rules = array();
}
