<?php

class Site {

	public static function header(){

	}

	public static function footer(){
		
	}

}