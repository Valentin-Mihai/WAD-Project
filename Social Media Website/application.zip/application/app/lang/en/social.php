<?php 

return array(

	/*
	|--------------------------------------------------------------------------
	| Social Language Lines
	|--------------------------------------------------------------------------
	|
	| The following language lines are used for views with Social Attributes
	|
	*/



	'follow_at'  		=> 		'Follow @',
	'share_facebook'	=>		'Share on Facebook',
	'share_twitter'		=>		'Share on Twitter',
	'share_google'		=>		'Share on Google Plus',
	'pin_it'			=>		'Pin It',
	'like'				=>		'Like',
	'tweet'				=>		'Tweet',
	'plus_one'			=>		'+1',
);