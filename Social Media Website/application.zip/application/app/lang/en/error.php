<?php 

return array(

	/*
	|--------------------------------------------------------------------------
	| Error Language Lines
	|--------------------------------------------------------------------------
	|
	| The following language lines are used for views with Errors
	|
	*/



	'403_message' 		=> 		'Whoopsie! It looks like this page does not exist (Error 403)',
	'404_message'		=>		'Whoopsie! It looks like this page does not exist (Error 404)',
	'500_message'		=>		'Whoopsie! It looks like this page does not exist (Error 500)',
	'generic_message'	=>		'Whoopsie! It looks like this page does not exist. Error: ',

	'return_home'		=>		'Click here to return home.',
);