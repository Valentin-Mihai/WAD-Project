<?php 

return include 'content/locale/lang.php';