@extends('layouts.master')

@section('content')

	<div class="container main_page_container">

		<?php echo $page->body; ?>

	</div>

@stop