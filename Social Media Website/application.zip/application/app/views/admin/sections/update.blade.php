<div class="callout callout-warning">Begin Update!</div>
<a href="<?= URL::to('perform_upgrade'); ?>">Click Here to Begin Your Update</a>