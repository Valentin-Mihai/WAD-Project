<?php include('includes/header.php'); ?>

	<div class="container main_page_container">

		<?php echo $page_content->body; ?>

	</div>

<?php include('includes/footer.php'); ?>