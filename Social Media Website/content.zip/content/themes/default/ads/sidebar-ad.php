<a href="http://codecanyon.net/item/ninja-media-script-viral-fun-media-sharing-site/6822888" target="_blank">
	<img src="/content/themes/default/assets/img/advertisement.png" width="302" height="252">
</a>