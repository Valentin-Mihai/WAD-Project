<?php

$lang = 'english';

return include 'content/locale/languages/' . $lang . '.php';